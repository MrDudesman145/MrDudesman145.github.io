window.Enemies = {
  "erio": {
    name: "Erio",
    src: "/images/characters/people/erio.png",
    pizzas: {
      "a": {
        pizzaId: "s001",
        maxHp: 50,
        level: 1,
      },
      "b": {
        pizzaId: "s002",
        maxHp: 50,
        level: 1,
      },
    }
  },
  "beth": {
    name: "Beth",
    src: "/images/characters/people/npc1.png",
    pizzas: {
      "a": {
        hp: 1,
        pizzaId: "f001",
        maxHp: 50,
        level: 1,
      },
    }
  },
  "chefRootie": {
    name: "Rootie",
    src: "/images/characters/people/secondBoss.png",
    pizzas: {
      "a": {
        pizzaId: "f002",
        maxHp: 100,
        level: 10,
      }
    }
  },
  "streetNorthBattle": {
    name: "Pizza Thug",
    src: "/images/characters/people/npc8.png",
    pizzas: {
      "a": {
        pizzaId: "s001",
        maxHp: 50,
        level: 2,
      }
    }
  },
  "diningRoomBattle": {
    name: "Pizza Thug",
    src: "/images/characters/people/npc8.png",
    pizzas: {
      "a": {
        pizzaId: "s001",
        maxHp: 60,
        level: 6,
      },
      "b": {
        pizzaId: "s002",
        maxHp: 20,
        level: 1,
      }
    }
  },
  "streetBattle": {
    name: "Pizza Thug",
    src: "/images/characters/people/npc8.png",
    pizzas: {
      "a": {
        pizzaId: "f002",
        maxHp: 50,
        level: 2,
      }
    }
  },
  "Manager": {
    name: "Manager",
    src: "/images/characters/people/npc8.png",
    pizzas: {
      "a": {
        pizzaId: "c001",
        maxHp: 100,
        level: 10,
      },
      "b": {
        pizzaId: "v002",
        maxHp: 50,
        level: 10,
      },
    }
  },
}