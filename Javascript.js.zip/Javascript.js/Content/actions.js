window.Actions = {
  damage1: {
    name: "Attack1",
    description: "Pillowy punch of dough",
    success: [
      { type: "textMessage", text: "{CASTER} uses {ACTION}!"},
      { type: "animation", animation: "spin"},
      { type: "stateChange", damage: 10}
    ]
  },
  saucyStatus: {
    name: "Cup o Sauce",
    description: "Applies the Saucy status",
    targetType: "friendly",
    success: [
      { type: "textMessage", text: "{CASTER} uses {ACTION}!"},
      { type: "stateChange", status: { type: "saucy", expiresIn: 3 } }
    ]
  },
  clumsyStatus: {
    name: "Green Oil",
    description: "Slippery mess of deliciousness",
    success: [
      { type: "textMessage", text: "{CASTER} uses {ACTION}!"},
      { type: "animation", animation: "glob", color: "#dafd2a" },
      { type: "stateChange", status: { type: "clumsy", expiresIn: 3 } },
      { type: "textMessage", text: "{TARGET} is slipping all around!"},
    ]
  },
   damage2: {
    name: "Grape Glob",
    description: "Throw Grape at your Enemy",
    success: [
      { type: "textMessage", text: "{CASTER} uses {ACTION}!"},
      { type: "animation", animation: "glob"},
      { type: "stateChange", damage: 12}
    ]
   },
    damage3: {
    name: "Great Gas",
    description: "Use your Inner Gas",
    success: [
      { type: "textMessage", text: "{CASTER}  {ACTION}!"},
      { type: "animation", animation: "glob"},
      { type: "stateChange", damage: 8}
    ]
   },
   clumsy2: {
    name: "Slime Slug",
    description: "Throw Slime at your Enemy",
    success: [
      { type: "textMessage", text: "{CASTER} uses {ACTION}!"},
      { type: "animation", animation: "glob", color: "#dafd2a" },
      { type: "stateChange", status: { type: "clumsy", expiresIn: 6 } },
      { type: "textMessage", text: "{TARGET} is slipping all around!"},
    ]
   },
  //Items
  item_recoverStatus: {
    name: "Warming Oven",
    description: "Feeling fresh and warm",
    targetType: "friendly",
    success: [
      { type: "textMessage", text: "{CASTER} uses a {ACTION}!"},
      { type: "stateChange", status: null },
      { type: "textMessage", text: "Feeling fresh!", },
    ]
  },
  item_recoverHp: {
    name: "Parmesean Cheese",
    targetType: "friendly",
    success: [
      { type:"textMessage", text: "{CASTER} sprinkles on some {ACTION}!", },
      { type:"stateChange", recover: 10, },
      { type:"textMessage", text: "{CASTER} recovers HP!", },
    ]
  },
    item_recoverHp2: {
    name: "Holy Dough",
    targetType: "friendly",
    success: [
      { type:"textMessage", text: "{CASTER} Uses Thy {ACTION}!", },
      { type:"stateChange", recover: 50, },
      { type:"textMessage", text: "{CASTER} recovers HP!", },
    ]
  },
}
